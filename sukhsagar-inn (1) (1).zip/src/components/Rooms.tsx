import React from 'react';
import { motion } from 'motion/react';
import { Wifi, Tv, Coffee, Wind, Bath, CircleCheck } from 'lucide-react';

const rooms = [
  {
    id: 1,
    title: 'Luxury AC Room',
    price: '₹2,500',
    image: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    features: ['Premium AC', 'King Size Bed', 'Smart TV', 'Ensuite Bath', 'Free Wi-Fi'],
    popular: true
  },
  {
    id: 2,
    title: 'Standard Non-AC Room',
    price: '₹1,500',
    image: 'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    features: ['Ventilated Space', 'Queen Size Bed', 'Flat Screen TV', 'Attached Bath', 'Free Wi-Fi'],
    popular: false
  },
  {
    id: 3,
    title: 'Family Suite',
    price: '₹4,000',
    image: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    features: ['Dual AC Units', '2 Large Beds', 'Lounge Area', 'Mini Fridge', 'Premium Bath', 'Free Wi-Fi'],
    popular: false
  }
];

export default function Rooms() {
  return (
    <section id="rooms" className="py-20 bg-warm-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h3 className="text-luxury-gold font-medium tracking-widest uppercase text-sm mb-2">Rest & Relax</h3>
          <h2 className="text-4xl md:text-5xl font-display font-semibold text-text-main mb-6">Premium Lodging</h2>
          <div className="w-24 h-1 bg-luxury-gold mx-auto rounded-full"></div>
          <p className="mt-6 text-text-light font-medium text-lg">
            Experience comfort like never before. Our hygienic, well-maintained rooms offer the perfect stay for families and travelers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {rooms.map((room, idx) => (
            <motion.div 
              key={room.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.6 }}
              className={`bg-white rounded-2xl overflow-hidden border ${room.popular ? 'border-luxury-gold shadow-xl relative' : 'border-royal-beige/50 shadow-md'} transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 flex flex-col`}
            >
              {room.popular && (
                 <div className="absolute top-4 right-4 z-10 bg-luxury-gold text-white text-xs font-bold uppercase tracking-wider py-1 px-3 rounded-full shadow-lg">
                    Most Popular
                 </div>
              )}
              
              <div className="h-60 overflow-hidden relative group">
                <img 
                  src={room.image} 
                  alt={room.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
              </div>
              
              <div className="p-8 flex-1 flex flex-col">
                <div className="flex justify-between items-start mb-4">
                   <h3 className="text-2xl font-display font-bold text-text-main">{room.title}</h3>
                   <div className="text-right">
                      <span className="block text-2xl font-bold text-luxury-gold">{room.price}</span>
                      <span className="text-xs text-text-light uppercase tracking-wide">per night</span>
                   </div>
                </div>
                
                <div className="h-px w-full bg-gradient-to-r from-royal-beige/20 via-royal-beige to-royal-beige/20 my-6"></div>
                
                <ul className="space-y-3 mb-8 flex-1">
                   {room.features.map((feature, i) => (
                      <li key={i} className="flex items-center text-text-body">
                         <CircleCheck size={18} className="text-luxury-gold mr-3 shrink-0" />
                         <span>{feature}</span>
                      </li>
                   ))}
                </ul>
                
                <a 
                  href="https://wa.me/918888213999" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className={`w-full py-4 rounded-xl font-semibold transition-all duration-300 text-center block ${
                  room.popular 
                  ? 'bg-luxury-gold text-white hover:bg-elegant-brown shadow-[0_4px_14px_0_rgba(201,162,39,0.39)]' 
                  : 'bg-soft-ivory text-elegant-brown hover:bg-luxury-gold hover:text-white border border-royal-beige'
                }`}>
                  Book Now
                </a>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
