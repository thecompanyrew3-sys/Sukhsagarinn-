import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ZoomIn } from 'lucide-react';

const galleryImages = [
  { id: 1, type: 'food', url: 'https://lh3.googleusercontent.com/d/1YOqjdFuBMRxH7bwRlLTdB9reXPYxDJYK', span: 'col-span-1 md:col-span-2 row-span-2' },
  { id: 2, type: 'interior', url: 'https://lh3.googleusercontent.com/d/1lPGGoDxlBGCBcjDT23yj7nyMg3sDO1Xp', span: 'col-span-1 md:col-span-2 row-span-1' },
  { id: 3, type: 'food', url: 'https://lh3.googleusercontent.com/d/1v_0h2llzhoh6pZ-uvl9Mx4eV6or7VxHt', span: 'col-span-1 row-span-1' },
  { id: 4, type: 'food', url: 'https://lh3.googleusercontent.com/d/1fc167pJJBt3XvZi43P-xUlH7iAxJmIye', span: 'col-span-1 md:col-span-2 row-span-1' },
  { id: 5, type: 'interior', url: 'https://lh3.googleusercontent.com/d/12MimkcovRiGp33waMGKvNq_rY-CQr1zm', span: 'col-span-1 md:col-span-2 row-span-2' },
];

export default function Gallery() {
  const [activeFilter, setActiveFilter] = useState('all');

  const filters = [
    { id: 'all', label: 'All Photos' },
    { id: 'food', label: 'Delicious Food' },
    { id: 'interior', label: 'Inner Ambience' }
  ];

  const filteredImages = activeFilter === 'all' 
    ? galleryImages 
    : galleryImages.filter(img => img.type === activeFilter);

  return (
    <section id="gallery" className="py-20 bg-champagne-cream/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h3 className="text-luxury-gold font-medium tracking-widest uppercase text-sm mb-2">Visual Tour</h3>
          <h2 className="text-4xl md:text-5xl font-display font-semibold text-text-main mb-6">Snapshot Gallery</h2>
          <div className="w-24 h-1 bg-luxury-gold mx-auto rounded-full mb-8"></div>
          
          <div className="flex flex-wrap justify-center gap-2 md:gap-4 mt-8">
            {filters.map(filter => (
              <button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id)}
                className={`px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  activeFilter === filter.id 
                  ? 'bg-elegant-brown text-white shadow-md' 
                  : 'bg-white text-text-light hover:text-text-main border border-royal-beige hover:border-luxury-gold'
                }`}
              >
                {filter.label}
              </button>
            ))}
          </div>
        </div>

        <motion.div 
          layout
          className="grid grid-cols-2 md:grid-cols-4 auto-rows-[200px] gap-4"
        >
          {filteredImages.map((img) => (
            <motion.div 
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.4 }}
              key={img.id} 
              className={`${activeFilter === 'all' ? img.span : 'col-span-1 md:col-span-2 row-span-1'} relative rounded-xl overflow-hidden group cursor-pointer shadow-sm hover:shadow-xl`}
            >
              <img 
                src={img.url} 
                alt={`Gallery photo ${img.id}`} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-elegant-brown/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center backdrop-blur-[2px]">
                <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center transform scale-0 group-hover:scale-100 transition-transform duration-500 delay-100">
                  <ZoomIn className="text-white drop-shadow-md" size={24} />
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

      </div>
    </section>
  );
}
