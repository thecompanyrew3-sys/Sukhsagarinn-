import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, CalendarDays, MapPin, MessageCircle, Instagram } from 'lucide-react';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About Us', href: '#about' },
    { name: 'Menu', href: '#menu' },
    { name: 'Rooms', href: '#rooms' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'Contact Us', href: '#contact' },
  ];

  return (
    <nav
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-champagne-cream/95 backdrop-blur-md shadow-md py-2' : 'bg-warm-white py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          
          {/* Left: Logo */}
          <div className="flex-shrink-0 flex items-center">
            <div className="flex items-center cursor-pointer">
               <img 
                 src="https://lh3.googleusercontent.com/d/1xA3gYAxLafVe5Uzs-8X_lQk2CLEPvlJh" 
                 alt="Sukhsagar Inn Logo" 
                 className="h-10 lg:h-12 w-auto object-contain"
                 referrerPolicy="no-referrer"
               />
            </div>
          </div>

          {/* Center: Desktop Menu */}
          <div className="hidden lg:flex items-center space-x-1 xl:space-x-4">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-text-body font-medium hover:text-luxury-gold px-3 py-2 rounded-md transition-colors relative group text-sm xl:text-base"
              >
                {link.name}
                <span className="absolute bottom-0 left-0 w-full h-[2px] bg-luxury-gold scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300"></span>
              </a>
            ))}
          </div>

          {/* Right: Actions */}
          <div className="hidden lg:flex items-center space-x-4">
            <div className="flex items-center gap-3 border-r border-royal-beige pr-4">
              <a href="https://www.instagram.com/hotel_sukhsagarinn?igsh=Z3dlcXg0YTNsejE5" target="_blank" rel="noopener noreferrer" className="text-[#E1306C] hover:text-[#C13584] transition-colors" title="Follow us on Instagram">
                <Instagram size={22} />
              </a>
              <a href="https://maps.app.goo.gl/C7r2EgzAvsLqSjiX6?g_st=ac" target="_blank" rel="noopener noreferrer" className="text-luxury-gold hover:text-elegant-brown transition-colors" title="Google Maps Location">
                <MapPin size={22} />
              </a>
              <a href="https://wa.me/918888213999" target="_blank" rel="noopener noreferrer" className="text-[#25D366] hover:text-[#20BE5A] transition-colors" title="Chat on WhatsApp">
                <MessageCircle size={22} />
              </a>
            </div>
            <div className="text-sm font-medium text-text-light cursor-pointer hover:text-text-main transition-colors border-r border-royal-beige pr-4">
              <span className="text-luxury-gold font-semibold">मराठी</span> | EN
            </div>
            <a href="tel:+918888213999" className="flex items-center gap-2 text-elegant-brown font-semibold hover:text-luxury-gold transition-colors">
              <Phone size={18} />
              <span>Call Now</span>
            </a>
            <a href="https://wa.me/918888213999" target="_blank" rel="noopener noreferrer" className="btn-primary flex items-center gap-2 text-sm xl:text-base">
              <CalendarDays size={18} />
              Book Room
            </a>
          </div>

          {/* Mobile menu button */}
          <div className="lg:hidden flex items-center gap-2 sm:gap-4">
            <a href="https://www.instagram.com/hotel_sukhsagarinn?igsh=Z3dlcXg0YTNsejE5" target="_blank" rel="noopener noreferrer" className="text-[#E1306C] hover:text-[#C13584] transition-colors p-1" aria-label="Follow us on Instagram">
              <Instagram size={24} />
            </a>
            <a href="https://maps.app.goo.gl/C7r2EgzAvsLqSjiX6?g_st=ac" target="_blank" rel="noopener noreferrer" className="text-luxury-gold hover:text-elegant-brown transition-colors p-1" aria-label="Google Maps Location">
              <MapPin size={24} />
            </a>
            <a href="https://wa.me/918888213999" target="_blank" rel="noopener noreferrer" className="text-[#25D366] hover:text-[#20BE5A] transition-colors p-1 mr-1" aria-label="Chat on WhatsApp">
              <MessageCircle size={24} />
            </a>
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-text-main p-1 focus:outline-none"
              aria-label="Toggle Menu"
            >
              {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-champagne-cream absolute top-full left-0 w-full shadow-lg border-t border-royal-beige">
          <div className="px-4 pt-2 pb-6 space-y-2">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="block px-3 py-3 text-base font-medium text-text-body hover:text-luxury-gold hover:bg-soft-ivory rounded-md"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {link.name}
              </a>
            ))}
            <div className="border-t border-royal-beige pt-4 mt-2 flex flex-col gap-3 px-3">
               <div className="text-sm font-medium text-text-light py-2">
                Language: <span className="text-luxury-gold font-semibold ml-2">मराठी</span> / EN
              </div>
              <a href="tel:+918888213999" className="flex items-center justify-center gap-2 bg-white text-elegant-brown border border-elegant-brown font-semibold py-3 rounded-md w-full">
                <Phone size={18} />
                Call Now
              </a>
              <a href="https://wa.me/918888213999" target="_blank" rel="noopener noreferrer" className="btn-primary flex items-center justify-center gap-2 w-full">
                <CalendarDays size={18} />
                Book Room
              </a>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
