import React from 'react';
import { Phone, MessageCircle, MapPin, CalendarDays, UtensilsCrossed } from 'lucide-react';
import { motion } from 'motion/react';

export default function Hero() {
  return (
    <section id="home" className="relative pt-24 pb-16 lg:pt-32 lg:pb-24 overflow-hidden bg-gradient-to-br from-soft-ivory via-royal-beige/30 to-champagne-cream/60">
      
      {/* Background Decorative Element */}
      <div className="absolute top-[-10%] right-[-5%] w-[40%] h-[60%] rounded-full bg-luxury-gold/5 blur-[120px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-8 items-center">
          
          {/* Left Side: Content */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8 mt-10 lg:mt-0"
          >
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/60 border border-luxury-gold/20 shadow-sm mb-6 backdrop-blur-sm">
                <span className="w-2 h-2 rounded-full bg-luxury-gold animate-pulse"></span>
                <span className="text-sm font-medium text-elegant-brown tracking-wide uppercase">Welcome to Luxury</span>
              </div>
              
              <h1 className="text-5xl lg:text-7xl font-display font-semibold text-text-main leading-tight mb-4">
                Pure Veg <span className="text-luxury-gold block mt-2">Family Restaurant</span> & Lodging
              </h1>
              
              <div className="text-xl lg:text-2xl font-serif text-elegant-brown italic opacity-90 mt-6 relative inline-block">
                "स्वाद सुधायचा... आठवण कायमची!"
                <div className="absolute -bottom-2 left-0 w-1/3 h-px bg-luxury-gold"></div>
              </div>
            </div>

            <div className="flex flex-wrap gap-4 pt-4">
              <a href="https://wa.me/918888213999" target="_blank" rel="noopener noreferrer" className="btn-primary flex items-center gap-2">
                <CalendarDays size={20} />
                Book Room
              </a>
              <a href="https://docs.google.com/spreadsheets/d/1T7NLTNNV8GoJyIOsA7LzVvL8at22ZZzQ/edit?usp=drivesdk&ouid=107687456649528209860&rtpof=true&sd=true" target="_blank" rel="noopener noreferrer" className="btn-secondary flex items-center gap-2">
                <UtensilsCrossed size={20} />
                View Menu
              </a>
              <a href="tel:+918888213999" className="bg-white text-text-main hover:text-luxury-gold border border-royal-beige font-medium px-6 py-3 rounded-md transition-all duration-300 shadow-sm flex items-center gap-2 hover:shadow-md">
                <Phone size={20} className="text-luxury-gold" />
                Call Now
              </a>
              <a href="https://wa.me/918888213999" target="_blank" rel="noopener noreferrer" className="bg-elegant-brown hover:bg-text-main text-white font-medium px-6 py-3 rounded-md transition-colors shadow-sm flex items-center gap-2 xl:px-4">
                <MessageCircle size={20} />
                <span className="hidden sm:inline">WhatsApp</span>
              </a>
            </div>
          </motion.div>

          {/* Right Side: Image Collage */}
          <motion.div 
             initial={{ opacity: 0, scale: 0.9 }}
             animate={{ opacity: 1, scale: 1 }}
             transition={{ duration: 0.8, delay: 0.2 }}
             className="relative pt-10"
          >
            {/* Pure Veg Badge */}
            <div className="absolute top-0 right-4 lg:-right-4 z-20 w-28 h-28 bg-white rounded-full flex flex-col items-center justify-center p-2 text-center ring-4 ring-luxury-gold/30 shadow-xl border-2 border-luxury-gold transform rotate-12 hover:rotate-0 transition-transform duration-500">
                <span className="w-4 h-4 rounded-sm border border-luxury-gold flex items-center justify-center mb-1">
                    <span className="w-2 h-2 bg-luxury-gold rounded-full"></span>
                </span>
                <span className="font-display font-bold text-lg leading-tight text-text-main pb-1">100%<br/>PURE</span>
                <span className="text-[10px] font-bold text-luxury-gold uppercase tracking-wider">Vegetarian</span>
            </div>

            <div className="grid grid-cols-2 gap-4 h-[500px]">
              <div className="col-span-1 space-y-4 h-full flex flex-col">
                <div className="h-[60%] w-full overflow-hidden rounded-tl-3xl rounded-br-3xl shadow-lg relative group">
                  <img src="https://lh3.googleusercontent.com/d/1vi4izHoH9uUZAyIz2mWFmHjjuhCZNg4F" referrerPolicy="no-referrer" alt="Authentic Indian Thali" className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700" />
                  <div className="absolute inset-0 bg-gradient-to-t from-elegant-brown/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <div className="h-[40%] w-full overflow-hidden rounded-bl-3xl shadow-lg relative group">
                  <img src="https://lh3.googleusercontent.com/d/1XWWUTMESfhOfvHFkKF7k23Bjto-8WlpE" referrerPolicy="no-referrer" alt="Luxury Dining Area" className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700" />
                </div>
              </div>
              <div className="col-span-1 space-y-4 h-full flex flex-col pt-12">
                <div className="h-[40%] w-full overflow-hidden rounded-tr-3xl shadow-lg relative group">
                  <img src="https://lh3.googleusercontent.com/d/1YOqjdFuBMRxH7bwRlLTdB9reXPYxDJYK" referrerPolicy="no-referrer" alt="Luxury Hotel Room" className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700" />
                </div>
                <div className="h-[60%] w-full overflow-hidden rounded-br-3xl rounded-tl-3xl shadow-lg relative group">
                  <img src="https://lh3.googleusercontent.com/d/1v_0h2llzhoh6pZ-uvl9Mx4eV6or7VxHt" referrerPolicy="no-referrer" alt="Delicious Paneer Dish" className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700" />
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Floating Quick Actions */}
      <div className="max-w-5xl mx-auto px-4 mt-16 relative z-20">
        <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-xl shadow-elegant-brown/5 border border-white p-2">
           <div className="grid grid-cols-2 md:grid-cols-5 divide-x divide-royal-beige/50">
             {[
               { icon: Phone, label: "Call Now", href: "tel:+918888213999" },
               { icon: MessageCircle, label: "WhatsApp", href: "https://wa.me/918888213999", target: "_blank" },
               { icon: MapPin, label: "Location", href: "https://maps.app.goo.gl/C7r2EgzAvsLqSjiX6?g_st=ac", target: "_blank" },
               { icon: CalendarDays, label: "Book Room", href: "https://wa.me/918888213999", target: "_blank" },
               { icon: UtensilsCrossed, label: "View Menu", href: "https://docs.google.com/spreadsheets/d/1T7NLTNNV8GoJyIOsA7LzVvL8at22ZZzQ/edit?usp=drivesdk&ouid=107687456649528209860&rtpof=true&sd=true", target: "_blank" },
             ].map((action, idx) => (
                <a key={idx} href={action.href} target={action.target} rel={action.target ? "noopener noreferrer" : undefined} className="flex flex-col items-center justify-center p-4 gap-2 hover:bg-soft-ivory/80 transition-colors group first:rounded-l-xl last:rounded-r-xl w-full">
                  <span className="w-10 h-10 rounded-full bg-champagne-cream flex items-center justify-center text-luxury-gold group-hover:bg-luxury-gold group-hover:text-white transition-all duration-300">
                    <action.icon size={18} />
                  </span>
                  <span className="text-sm font-medium text-text-body group-hover:text-text-main transition-colors">{action.label}</span>
                </a>
             ))}
           </div>
        </div>
      </div>
    </section>
  );
}
