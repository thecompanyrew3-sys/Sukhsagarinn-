import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';

const reviews = [
  {
    id: 1,
    name: 'Rajesh Sharma',
    role: 'Local Guide',
    rating: 5,
    text: 'Absolutely fantastic food and service. The Punjabi Thali is a must-try. The rooms are clean, spacious, and very comfortable for families. Highly recommended!'
  },
  {
    id: 2,
    name: 'Priya Deshmukh',
    role: 'Frequent Traveler',
    rating: 5,
    text: 'A hidden gem! The luxury ambiance mixed with authentic Indian flavors makes Sukhsagar Inn special. Their staff is extremely polite and welcoming.'
  },
  {
    id: 3,
    name: 'Amit Patel',
    role: 'Food Blogger',
    rating: 5,
    text: 'Pure veg heaven. Ingredients taste fresh, and you can tell they care about quality. Stayed here for two nights, the AC suite was top-notch.'
  }
];

export default function Reviews() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextReview = () => {
    setCurrentIndex((prev) => (prev + 1) % reviews.length);
  };

  const prevReview = () => {
    setCurrentIndex((prev) => (prev - 1 + reviews.length) % reviews.length);
  };

  return (
    <section id="reviews" className="py-24 bg-soft-ivory relative overflow-hidden">
      <Quote className="absolute top-10 left-10 text-royal-beige/40 w-48 h-48 transform -rotate-12" />
      <Quote className="absolute bottom-10 right-10 text-royal-beige/40 w-64 h-64 transform rotate-12" />
      
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="text-center mb-16">
           <h3 className="text-luxury-gold font-medium tracking-widest uppercase text-sm mb-2">Testimonials</h3>
           <h2 className="text-4xl md:text-5xl font-display font-semibold text-text-main mb-6">What Our Guests Say</h2>
           <div className="w-24 h-1 bg-luxury-gold mx-auto rounded-full"></div>
        </div>

        <div className="relative">
          <div className="overflow-hidden rounded-3xl bg-white shadow-xl shadow-elegant-brown/5 border border-royal-beige/30 p-8 md:p-16">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.5 }}
                className="text-center"
              >
                <div className="flex justify-center mb-6">
                  {[...Array(reviews[currentIndex].rating)].map((_, i) => (
                    <Star key={i} className="text-luxury-gold fill-luxury-gold mx-1" size={24} />
                  ))}
                </div>
                
                <p className="text-xl md:text-2xl lg:text-3xl font-display italic text-text-body leading-relaxed mb-10">
                  "{reviews[currentIndex].text}"
                </p>
                
                <div>
                   <h4 className="text-lg font-bold text-text-main">{reviews[currentIndex].name}</h4>
                   <p className="text-sm font-medium text-luxury-gold uppercase tracking-widest mt-1">{reviews[currentIndex].role}</p>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          <div className="flex justify-center gap-4 mt-8">
            <button 
              onClick={prevReview}
              className="w-12 h-12 rounded-full border-2 border-luxury-gold flex items-center justify-center text-luxury-gold hover:bg-luxury-gold hover:text-white transition-colors"
            >
               <ChevronLeft size={24} />
            </button>
            <button 
               onClick={nextReview}
               className="w-12 h-12 rounded-full border-2 border-luxury-gold flex items-center justify-center text-luxury-gold hover:bg-luxury-gold hover:text-white transition-colors"
            >
               <ChevronRight size={24} />
            </button>
          </div>
        </div>

      </div>
    </section>
  );
}
