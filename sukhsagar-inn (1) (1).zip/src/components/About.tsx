import React from 'react';
import { motion } from 'motion/react';
import { Users, Utensils, Award, Leaf } from 'lucide-react';

export default function About() {
  const stats = [
    { icon: Utensils, title: '100+', subtitle: 'Delicious Food Items' },
    { icon: Users, title: '5000+', subtitle: 'Happy Customers' },
    { icon: Award, title: '10+ Years', subtitle: 'Of Trust & Service' },
    { icon: Leaf, title: '100%', subtitle: 'Pure Vegetarian' },
  ];

  return (
    <section id="about" className="py-20 bg-warm-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-center">
          
          {/* Left: Content */}
          <div className="space-y-6">
             <div className="pb-2">
                <img 
                   src="https://lh3.googleusercontent.com/d/1xA3gYAxLafVe5Uzs-8X_lQk2CLEPvlJh" 
                   alt="Sukhsagar Inn Logo" 
                   className="h-20 w-auto object-contain"
                   referrerPolicy="no-referrer"
                />
             </div>
             
             <div>
                <h3 className="text-luxury-gold font-medium tracking-widest uppercase text-sm mb-2">About Us</h3>
                <h2 className="text-3xl md:text-4xl font-display font-semibold text-text-main leading-tight">
                  Welcome to <br/> Sukhsagar Inn
                </h2>
             </div>
             
             <p className="text-text-body leading-relaxed">
                Sukhsagar Inn is a premier pure veg family restaurant with comfortable lodging facilities. 
                We serve hygienic, tasty, and quality food in a warm & friendly atmosphere designed for 
                families to create beautiful memories together.
             </p>
             
             <p className="text-text-light leading-relaxed">
                Experience royal hospitality where every dish is crafted with passion, and every stay feels like home.
             </p>
             
             <div className="pt-4">
                <button className="text-luxury-gold hover:text-elegant-brown font-semibold flex items-center gap-2 group transition-colors uppercase tracking-wide text-sm border-b border-luxury-gold pb-1 self-start">
                   Know More
                   <span className="transform group-hover:translate-x-1 transition-transform">→</span>
                </button>
             </div>
          </div>

          {/* Center: Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
             {stats.map((stat, idx) => (
                <motion.div 
                   key={idx}
                   initial={{ opacity: 0, y: 20 }}
                   whileInView={{ opacity: 1, y: 0 }}
                   viewport={{ once: true }}
                   transition={{ delay: idx * 0.1, duration: 0.6 }}
                   className="bg-soft-ivory p-6 rounded-2xl text-center border border-royal-beige/50 hover:border-luxury-gold/30 hover:shadow-lg transition-all duration-300 group"
                >
                   <div className="w-12 h-12 mx-auto bg-champagne-cream rounded-full flex items-center justify-center text-luxury-gold mb-4 group-hover:scale-110 transition-transform">
                      <stat.icon size={24} />
                   </div>
                   <h4 className="text-2xl font-display font-bold text-text-main mb-1">{stat.title}</h4>
                   <p className="text-sm text-text-light font-medium">{stat.subtitle}</p>
                </motion.div>
             ))}
          </div>

          {/* Right: Image / Video block */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="h-full w-full min-h-[500px] md:min-h-[600px] overflow-hidden rounded-2xl shadow-xl relative bg-white"
          >
             <iframe 
               src="https://www.instagram.com/reel/DXChxuIDa_M/embed/" 
               className="absolute inset-0 w-full h-full"
               frameBorder="0" 
               scrolling="no" 
               allowTransparency={true}
               allow="encrypted-media"
             ></iframe>
             <div className="absolute inset-0 border-[12px] border-warm-white/10 rounded-2xl pointer-events-none"></div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
