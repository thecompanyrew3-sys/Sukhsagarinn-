import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

const menuCategories = [
  {
    id: 1,
    title: 'Punjabi',
    desc: 'Rich, creamy curries & tandoori delights.',
    image: 'https://lh3.googleusercontent.com/d/1nrI4reMWTkiowekf6oXS50fL_EYudsIp'
  },
  {
    id: 2,
    title: 'South Indian',
    desc: 'Crispy dosas, fluffy idlis & filtering coffee.',
    image: 'https://lh3.googleusercontent.com/d/1UC979eaYdKVdIUfXiJXshxrsh897J5AD'
  },
  {
    id: 3,
    title: 'Chinese',
    desc: 'Wok-tossed noodles & bold Asian flavors.',
    image: 'https://images.unsplash.com/photo-1585032226651-759b368d7246?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 4,
    title: 'Special Thali',
    desc: 'A complete Indian feast on a grand platter.',
    image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'
  }
];

export default function Menu() {
  return (
    <section id="menu" className="py-20 bg-champagne-cream/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h3 className="text-luxury-gold font-medium tracking-widest uppercase text-sm mb-2">Taste The Best</h3>
          <h2 className="text-4xl md:text-5xl font-display font-semibold text-text-main mb-6">Our Special Menu</h2>
          <div className="w-24 h-1 bg-luxury-gold mx-auto rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          
          {menuCategories.map((item, idx) => (
            <motion.a 
              href="https://docs.google.com/spreadsheets/d/1T7NLTNNV8GoJyIOsA7LzVvL8at22ZZzQ/edit?usp=drivesdk&ouid=107687456649528209860&rtpof=true&sd=true"
              target="_blank"
              rel="noopener noreferrer"
              key={item.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.6 }}
              className="bg-white rounded-2xl overflow-hidden shadow-md group cursor-pointer border border-royal-beige/40 hover:shadow-xl transition-all duration-300 block"
            >
              <div className="h-64 overflow-hidden relative">
                <img 
                  src={item.image} 
                  alt={item.title} 
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-80"></div>
                <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
                  <h3 className="text-white font-display text-2xl font-semibold tracking-wide drop-shadow-md">{item.title}</h3>
                  <div className="w-10 h-10 rounded-full bg-luxury-gold/90 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transform translate-x-4 group-hover:translate-x-0 transition-all duration-300">
                    <ArrowRight size={20} />
                  </div>
                </div>
              </div>
              <div className="p-6">
                <p className="text-text-body">{item.desc}</p>
              </div>
            </motion.a>
          ))}

          {/* Highlighted Call-to-action Card */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="md:col-span-2 lg:col-span-2 bg-elegant-brown rounded-2xl p-8 lg:p-12 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-8 relative overflow-hidden"
          >
             <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1579548122080-c35fd6820ecb?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80')] bg-cover bg-center mix-blend-overlay"></div>
             
             <div className="relative z-10 sm:max-w-[70%]">
                <h3 className="text-3xl lg:text-4xl font-display font-semibold text-white mb-4">Discover Our Full Spread</h3>
                <p className="text-champagne-cream/90 text-lg">
                  Craving more? We have an extensive menu of 100+ pure veg delicacies, ranging from soups and starters to royal main courses and desserts.
                </p>
             </div>
             
             <div className="relative z-10 w-full sm:w-auto mt-4 sm:mt-0">
               <a href="https://docs.google.com/spreadsheets/d/1T7NLTNNV8GoJyIOsA7LzVvL8at22ZZzQ/edit?usp=drivesdk&ouid=107687456649528209860&rtpof=true&sd=true" target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto btn-primary bg-luxury-gold hover:bg-white hover:text-luxury-gold !text-lg !px-8 !py-4 shadow-[0_0_20px_rgba(201,162,39,0.4)] whitespace-nowrap inline-block text-center rounded-xl">
                 View Full Menu
               </a>
             </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
