import React from 'react';
import { Phone, Mail, MapPin, Facebook, Instagram, Twitter, Clock } from 'lucide-react';

export default function Footer() {
  return (
    <footer id="contact" className="bg-elegant-brown text-champagne-cream pt-20 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Brand Col */}
          <div className="space-y-6">
            <div className="flex items-center">
               <img 
                 src="https://lh3.googleusercontent.com/d/1xA3gYAxLafVe5Uzs-8X_lQk2CLEPvlJh" 
                 alt="Sukhsagar Inn Logo" 
                 className="h-16 w-auto object-contain bg-white px-3 py-2 rounded-lg"
                 referrerPolicy="no-referrer"
               />
            </div>
            <p className="text-royal-beige/80 leading-relaxed text-sm pr-4">
              A premium 100% pure veg family restaurant and luxury lodging offering a royal experience. Taste the tradition, stay in comfort.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/10 hover:bg-luxury-gold hover:text-white flex items-center justify-center transition-all duration-300 text-luxury-gold">
                <Facebook size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/10 hover:bg-luxury-gold hover:text-white flex items-center justify-center transition-all duration-300 text-luxury-gold">
                <Instagram size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/10 hover:bg-luxury-gold hover:text-white flex items-center justify-center transition-all duration-300 text-luxury-gold">
                <Twitter size={18} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-display text-xl font-medium mb-6 flex items-center">
              Quick Links
              <span className="w-12 h-[2px] bg-luxury-gold ml-4"></span>
            </h4>
            <ul className="space-y-3 font-medium">
              {['Home', 'About Us', 'Special Menu', 'Luxury Rooms', 'Photo Gallery', 'Guest Reviews'].map((link, idx) => (
                <li key={idx}>
                  <a href={`#${link.split(' ')[0].toLowerCase()}`} className="text-royal-beige/80 hover:text-luxury-gold flex items-center gap-2 group transition-colors">
                    <span className="w-0 group-hover:w-2 h-[2px] bg-luxury-gold transition-all duration-300"></span>
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-white font-display text-xl font-medium mb-6 flex items-center">
              Contact Info
              <span className="w-12 h-[2px] bg-luxury-gold ml-4"></span>
            </h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-4">
                <MapPin className="text-luxury-gold mt-1 shrink-0" size={20} />
                <a href="https://maps.app.goo.gl/C7r2EgzAvsLqSjiX6?g_st=ac" target="_blank" rel="noopener noreferrer" className="text-royal-beige/80 text-sm leading-relaxed hover:text-luxury-gold transition-colors">
                  Sukhsagar Inn<br/>Open in Google Maps
                </a>
              </li>
              <li className="flex items-center gap-4">
                <Phone className="text-luxury-gold shrink-0" size={20} />
                <span className="text-royal-beige/80 text-sm">
                  <a href="tel:+918888213999" className="hover:text-luxury-gold transition-colors">+91 88882 13999</a>
                </span>
              </li>
              <li className="flex items-center gap-4">
                <Mail className="text-luxury-gold shrink-0" size={20} />
                <span className="text-royal-beige/80 text-sm">
                  bookings@sukhsagarinn.com
                </span>
              </li>
              <li className="flex items-start gap-4">
                <Clock className="text-luxury-gold mt-1 shrink-0" size={20} />
                <span className="text-royal-beige/80 text-sm leading-relaxed">
                  Restaurant: 11:00 AM - 11:30 PM<br/>Lodging Check-in: 12:00 PM
                </span>
              </li>
            </ul>
          </div>

          {/* Location QR Placeholer */}
          <div className="flex flex-col items-start lg:items-center">
             <h4 className="text-white font-display text-xl font-medium mb-6 text-left lg:text-center w-full flex items-center lg:block">
              Scan For Menu
              <span className="w-12 h-[2px] bg-luxury-gold ml-4 lg:hidden"></span>
            </h4>
             <div className="bg-white p-4 rounded-xl shadow-lg border border-luxury-gold/50">
               <img 
                 src="https://lh3.googleusercontent.com/d/1_BvRlpKePtPtZ6Oj-G9Sqz-eAU9K6Dxt" 
                 alt="Menu QR Code" 
                 className="w-32 h-32 object-contain"
                 referrerPolicy="no-referrer"
               />
             </div>
             <p className="mt-4 text-sm text-royal-beige/60 text-center">Scan to open our digital menu</p>
          </div>

        </div>

        {/* Bottom Footer */}
        <div className="border-t border-royal-beige/20 pt-8 mt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-royal-beige/60">
          <p>&copy; {new Date().getFullYear()} Sukhsagar Inn. All rights reserved.</p>
          <div className="flex items-center gap-6">
             <a href="#" className="hover:text-luxury-gold transition-colors">Privacy Policy</a>
             <a href="#" className="hover:text-luxury-gold transition-colors">Terms & Conditions</a>
          </div>
        </div>

      </div>
    </footer>
  );
}
