import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Menu from './components/Menu';
import Rooms from './components/Rooms';
import Gallery from './components/Gallery';
import Reviews from './components/Reviews';
import Footer from './components/Footer';
import { Phone } from 'lucide-react';

function App() {
  const [showCallMsg, setShowCallMsg] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowCallMsg(false);
    }, 4000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="flex justify-center min-h-screen bg-warm-white w-full overflow-hidden relative">
      <div className="w-full max-w-[100vw]">
        <Navbar />
        <main>
          <Hero />
          <About />
          <Menu />
          <Rooms />
          <Gallery />
          <Reviews />
        </main>
        <Footer />
      </div>

      <div className="fixed bottom-6 lg:bottom-10 right-6 lg:right-10 z-50 flex flex-col gap-4">
        {/* Call Icon */}
        <div className="relative flex items-center justify-end">
           <span className={`absolute right-full mr-4 bg-white text-luxury-gold px-4 py-2 text-sm font-bold rounded-lg shadow-lg whitespace-nowrap transition-all duration-500 origin-right ${showCallMsg ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'}`}>
             Call Now!
             <div className="absolute top-1/2 -right-2 transform -translate-y-1/2 border-[6px] border-transparent border-l-white"></div>
           </span>

           <a
             href="tel:+918888213999"
             className="bg-elegant-brown text-white p-4 rounded-full shadow-lg hover:bg-luxury-gold hover:scale-110 transition-all duration-300 flex items-center justify-center group"
           >
             <Phone size={32} />
             <span className="absolute right-full mr-4 bg-white text-elegant-brown px-3 py-1 text-sm font-semibold rounded shadow-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none whitespace-nowrap hidden group-hover:block">Call Us</span>
           </a>
        </div>

        {/* WhatsApp Icon */}
        <div className="relative flex items-center justify-end">
          <a
            href="https://wa.me/918888213999"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-[#25D366] text-white p-4 rounded-full shadow-lg hover:bg-[#20BE5A] hover:scale-110 transition-all duration-300 flex items-center justify-center group"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
            </svg>
            <span className="absolute right-full mr-4 bg-white text-[#25D366] px-3 py-1 text-sm font-semibold rounded shadow-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none whitespace-nowrap">Chat with us</span>
          </a>
        </div>
      </div>
    </div>
  );
}

export default App;
